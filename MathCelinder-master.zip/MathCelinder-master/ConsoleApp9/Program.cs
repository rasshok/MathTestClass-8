﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp12
{
    public class Geometry
    {
        static void Main(string[] args)
        {

        }
        public double aaa(double r, double h)
        {
            double v = 3.14 * (r * r) * h;
            return v;
        }
    }
}